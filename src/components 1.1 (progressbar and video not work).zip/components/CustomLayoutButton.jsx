// import React from "react";
// import { useNavigate } from "react-router-dom";

// const CustomLayoutButton = () => {
//   const navigate = useNavigate();

//   const handleClick = () => {
//     navigate("/create-layout");
//   };

//   return <button onClick={handleClick}>Create Custom Layout</button>;
// };

// export default CustomLayoutButton;

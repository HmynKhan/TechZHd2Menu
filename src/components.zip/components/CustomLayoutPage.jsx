import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  addDivision,
  updateDivision,
  saveLayout,
  loadLayout,
  deleteLayout,
} from "../store/layoutSlice";
import LayoutPreview from "./LayoutPreview";
import ScreenDivision from "./ScreenDivision";
import images from "../assets/images"; // Assuming you have an array of image objects
import videos from "../assets/videos"; // Assuming you have an array of video objects
import Preview from "./Preview"; // Import the PreviewLayout component
import "./CustomLayout.css";
import TimelineMedia from "./TimelineMedia";

const CustomLayoutPage = () => {
  const dispatch = useDispatch();
  const layouts = useSelector((state) => state.layout.layouts);
  const selectedLayout = useSelector((state) => state.layout.currentLayout);
  const [layoutName, setLayoutName] = useState("");
  const [draggedMedia, setDraggedMedia] = useState(null); // State to store the dragged media ID and type
  const [isPreviewOpen, setIsPreviewOpen] = useState(false); // State to control the preview modal
  const [selectedMedia, setSelectedMedia] = useState(null);

  const handleAddDivision = () => {
    const newDivision = {
      id: Date.now(), // Unique ID for each division
      x: 0,
      y: 0,
      width: 300,
      height: 200,
      imageSrcs: [], // Initialize with an empty array to store multiple images or videos
    };
    dispatch(addDivision(newDivision));
  };

  const handleSaveLayout = () => {
    if (layoutName) {
      dispatch(saveLayout({ name: layoutName }));
      setLayoutName("");
      saveLayout("");
    } else {
      alert("Please enter a layout name.");
    }
  };

  const handleLoadLayout = (id) => {
    dispatch(loadLayout(id)); // Load the layout into the editable area
  };

  const handleSelectLayout = (layout) => {
    dispatch(loadLayout(layout.id)); // Load the selected layout into the editable area
  };

  const handleDeleteLayout = (id) => {
    dispatch(deleteLayout(id));
  };

  const handleDivisionChange = (id, changes) => {
    dispatch(updateDivision({ id, changes }));
  };

  const handleDragStart = (media) => {
    setDraggedMedia(media); // Set the dragged media ID and type
  };

  const handleDropMedia = (divisionId, event) => {
    event.preventDefault();

    if (draggedMedia !== null) {
      const { id, type } = draggedMedia;

      // Find the media in the respective array by ID
      const mediaObj =
        type === "image"
          ? images.find((img) => img.id === id)
          : videos.find((video) => video.id === id);

      if (mediaObj) {
        // Find the division within the selected layout
        const division = selectedLayout.divisions.find(
          (div) => div.id === divisionId
        );

        if (division) {
          // Add the new media to the array of imageSrcs
          const updatedImageSrcs = [
            ...(division.imageSrcs || []),
            mediaObj.src,
          ];
          dispatch(
            updateDivision({
              id: divisionId,
              changes: { imageSrcs: updatedImageSrcs },
            })
          );
        }
      }
    }
  };

  const handlePreviewClick = () => {
    setIsPreviewOpen(true);
  };

  const handleClosePreview = () => {
    setIsPreviewOpen(false);
  };

  const handleMediaClick = (src, id) => {
    setSelectedMedia({ src, id });
  };

  const handleRemoveMedia = () => {
    const { id, src } = selectedMedia;
    const division = selectedLayout.divisions.find((div) =>
      div.imageSrcs.includes(src)
    );

    if (division) {
      const updatedImageSrcs = division.imageSrcs.filter(
        (imageSrc) => imageSrc !== src
      );
      dispatch(
        updateDivision({
          id: division.id,
          changes: { imageSrcs: updatedImageSrcs },
        })
      );
    }
    setSelectedMedia(null);
  };
  return (
    <div style={{ margin: "20px", backgroundColor: "#FAF9F6" }}>
      <h1
        style={{
          textAlign: "center",
          fontFamily: "Arial, sans-serif",
          color: "#333",
        }}
      >
        Create Custom Layout
      </h1>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <input
          type="text"
          value={layoutName}
          onChange={(e) => setLayoutName(e.target.value)}
          placeholder="Enter layout name"
          style={{
            padding: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            marginBottom: "10px",
            width: "300px",
            fontSize: "16px",
          }}
        />
        <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
          <button
            onClick={handleSaveLayout}
            style={{
              padding: "10px 20px",
              backgroundColor: "#007bff",
              color: "white",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              transition: "background-color 0.3s ease",
            }}
            onMouseOver={(e) => (e.target.style.backgroundColor = "#0056b3")}
            onMouseOut={(e) => (e.target.style.backgroundColor = "#007bff")}
          >
            Save Layout
          </button>
          <button
            onClick={handleAddDivision}
            style={{
              padding: "10px 20px",
              backgroundColor: "#28a745",
              color: "white",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              transition: "background-color 0.3s ease",
            }}
            onMouseOver={(e) => (e.target.style.backgroundColor = "#218838")}
            onMouseOut={(e) => (e.target.style.backgroundColor = "#28a745")}
          >
            Add Division
          </button>
        </div>
        <LayoutPreview
          divisions={selectedLayout.divisions}
          onDivisionChange={handleDivisionChange}
          onDropImage={handleDropMedia}
          style={{
            border: "3px solid #ddd",
            borderRadius: "10px",
            padding: "20px",
            backgroundColor: "#f8f9fa",
            width: "80%",
            marginBottom: "20px",
          }}
        />
        {selectedLayout.divisions.map((div, index) => (
          <ScreenDivision key={div.id} index={index} division={div} />
        ))}
      </div>

      <h2 className="custom-layout-title">Saved Layouts</h2>
      <div className="custom-layout-container">
        {layouts.map((layout) => (
          <div
            key={layout.id}
            className={`custom-layout-card ${
              selectedLayout && selectedLayout.id === layout.id
                ? "custom-layout-card-selected"
                : ""
            }`}
            onClick={() => handleSelectLayout(layout)}
          >
            <h3 className="custom-layout-name">{layout.name}</h3>
            <div className="custom-layout-button-container">
              <button
                className="custom-layout-button"
                onClick={() => handleLoadLayout(layout.id)}
              >
                Load
              </button>
              <button
                className="custom-layout-button custom-layout-button-delete"
                onClick={() => handleDeleteLayout(layout.id)}
              >
                Delete
              </button>
            </div>
            <div className="custom-layout-preview-container">
              <LayoutPreview divisions={layout.divisions} isPreview={true} />
            </div>
          </div>
        ))}
      </div>

      {selectedLayout && (
        <div className="custom-layout-timeline-container">
          <h2 className="custom-layout-timeline-title">
            Timeline for Layout: {selectedLayout.name}
          </h2>
          <div className="custom-layout-timeline">
            {selectedLayout.divisions.map((division, index) => (
              <div
                key={division.id}
                className="custom-layout-timeline-division"
                onDrop={(e) => handleDropMedia(division.id, e)}
                onDragOver={(e) => e.preventDefault()}
              >
                <div className="custom-layout-timeline-index">{index + 1}</div>
                <div className="custom-layout-timeline-content">
                  {division.imageSrcs &&
                    division.imageSrcs.map((src, i) =>
                      src.endsWith(".mp4") ? (
                        <video
                          key={i}
                          src={src}
                          controls={false}
                          muted
                          autoPlay
                          className="custom-layout-video"
                          onClick={() => handleMediaClick(src, i)}
                        />
                      ) : (
                        <img
                          key={i}
                          src={src}
                          alt="Dropped"
                          className="custom-layout-image"
                          onClick={() => handleMediaClick(src, i)}
                        />
                      )
                    )}
                </div>
              </div>
            ))}
            <button
              onClick={handlePreviewClick}
              className="custom-layout-preview-button"
            >
              Preview Layout
            </button>
          </div>
        </div>
      )}

      <h2>Images & Videos Gallery</h2>
      <div style={{ display: "flex", flexWrap: "wrap", cursor: "pointer" }}>
        {images.map((item, index) => (
          <img
            src={item.src}
            key={index}
            alt="images"
            height={80}
            width={130}
            style={{ margin: "5px" }}
            draggable
            onDragStart={() => handleDragStart({ id: item.id, type: "image" })} // Set the image ID on drag start
          />
        ))}
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", cursor: "pointer" }}>
        {/* <span>Video</span> */}
        {videos.map((video, index) => (
          <video
            key={index}
            src={video.src}
            height={80}
            width={130}
            autoPlay
            muted
            loop
            controls={false}
            style={{ margin: "5px" }}
            draggable
            onDragStart={() => handleDragStart({ id: video.id, type: "video" })} // Set the video ID on drag start
          />
        ))}
      </div>

      {isPreviewOpen && (
        <Preview layout={selectedLayout} onClose={handleClosePreview} />
      )}

      {selectedMedia && (
        <TimelineMedia
          mediaSrc={selectedMedia.src}
          mediaId={selectedMedia.id}
          onRemove={handleRemoveMedia}
          onClose={() => setSelectedMedia(null)}
        />
      )}
    </div>
  );
};

export default CustomLayoutPage;

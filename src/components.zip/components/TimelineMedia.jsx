import React from "react";
import "./TimelineMedia.css";

const TimelineMedia = ({ mediaSrc, mediaId, onRemove, onClose }) => {
  return (
    <div className="timeline-media-overlay">
      <div className="timeline-media-content">
        <button className="timeline-media-close-button" onClick={onClose}>
          Close
        </button>
        {mediaSrc.endsWith(".mp4") ? (
          <video
            src={mediaSrc}
            controls={false}
            muted
            className="timeline-media-video"
            style={{ pointerEvents: "none" }}
          />
        ) : (
          <img src={mediaSrc} alt="Media" className="timeline-media-image" />
        )}
        <p>ID: {mediaId}</p>
        <button className="timeline-media-remove-button" onClick={onRemove}>
          Remove Media
        </button>
      </div>
    </div>
  );
};

export default TimelineMedia;
